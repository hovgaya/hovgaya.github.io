# Types of modification of Armenian personal names in contact settings — first pass (22 November 2026)

## Problem and approach

The question is not *whether* Armenian names change in the diaspora but *which operations* change them, under which
pressure, and in what proportions. Two kinds of evidence are combined.

1. **Linked records.** In the Armenian Immigration Project (AIA, North America to 1939) every recorded surname is
   paired with a standardised form. The pair shows the operation directly: *Hagopian → Agopian* (h dropped),
   *Kasparian → Gasparian* (voicing), *Bedrosian → Peters* (translation).
2. **Unlinked lists.** Present-day or 20th-century name lists (Glendale and Boston city payrolls, French death
   register for Marseille) give no pairs. There the detector (D7) finds the Armenian surnames, and the *profile* of
   their spellings and of the given names borne with them is counted.

The operations are coded at the level of the name's segments (prefix *Ter-/Der-/Hadji-*, stem, ending), in the
same spirit as the segment:operation coding of the article.

## Sources used

| Corpus | Persons | Armenian surnames (tiers A–B) | Licence / status |
|---|---|---|---|
| Armenian Immigration Project, ship manifests and border crossings (to 1939) | 78,501 entries | all (Armenian by selection) | compiler's terms not stated: aggregates only |
| Glendale CA city employees 2012 (Transparent California) | 2,482 | 276 (11.1%) | public records; names only kept, pay discarded |
| Glendale CA city employees 2025 | 2,458 | 361 (14.7%) | as above |
| Boston MA city employees 2011 (data.boston.gov) | 20,509 | 31 (0.15%) | open data |
| Boston MA city employees 2025 | 25,397 | 34 (0.13%) | open data |
| Marseille, deaths registered 1970–2019 (INSEE *Fichier des personnes décédées*) | 413,786 | 5,952 (1.4%) | Licence Ouverte 2.0; 34 records under INSEE opposition excluded |
| Argentina, residents with DNI, December 2021 (RENAPER surname distribution by province) | 46,231,598 | 12,809 (0.03%; surnames with ≥10 bearers per province only) | CC BY 4.0 |

Only aggregate tables are produced. No file lists individuals; example names appear only for groups of ≥50 persons and names borne ≥3 times (see ETHICS_AND_DATA_GOVERNANCE.md).

## Part A. Operations visible in linked records (AIA)

*Revised 23 Nov 2026: the h-rule now counts only a free h (not the h of ch, sh, kh, gh, zh, th), and -chian after a stem in sh/ch is no longer counted as a new ending; the former "replacement / translation" row is renamed, because it also holds distinct surnames the source groups under one standard form.*

Share of all records showing each operation; one record can show several. 30.1% of records keep the standard form.

| Segment | Operation | Records | % | Typical pairs |
|---|---|---|---|---|
| — | residual respelling (clerical / phonetic) | 21,558 | 27.8 | *Arslanian → Aslanian*; *Najarian → Nazarian*; *Krikorian → Kirkorian* |
| Stem | vowel spelling | 19,953 | 25.7 | *Mouradian → Mooradian*; *Manougian → Manoogian*; *Giragosian → Guiragossian* |
| Stem | voicing alternation (Western b/g/d ~ Eastern p/k/t) | 8,641 | 11.1 | *Kasparian → Gasparian*; *Manougian → Manoukian*; *Ghazarian → Kazarian* |
| Stem | consonant doubling (ss, nn ...) | 7,866 | 10.1 | *Sarkisian → Sarkissian*; *Minasian → Minassian*; *Bedrosian → Bedrossian* |
| Stem | French-type orthography (dj, tch, ch for sh, ou) | 7,016 | 9.0 | *Keshishian → Kechichian*; *Najarian → Nadjarian*; *Ajemian → Adjemian* |
| Whole name | whole-form change (replacement, translation, or a different surname grouped under the standard form) | 3,951 | 5.1 | *Ghazarian → Kizirian*; *Hagopian → Yacoubian*; *Ghougasian → Gagossian* |
| Ending | → -djian (French/Western spelling of -jian) | 3,429 | 4.4 | *Boyajian → Boyadjian*; *Kazanjian → Kazandjian*; *Demirjian → Demirdjian* |
| Stem | English-type orthography (oo for u, gh for g) | 3,103 | 4.0 | *Boghosian → Bogossian*; *Ghazarian → Kazarian*; *Boghosian → Bogosian* |
| Ending | → -yan (Eastern / post-Soviet romanisation) | 2,896 | 3.7 | *Babaian → Babayan*; *Yesaian → Essayan*; *Kalfaian → Kalfayan* |
| Ending | → -ian (Western / diaspora) | 2,402 | 3.1 | *Boyajian → Boyagian*; *Tashjian → Tashian*; *Kalpakjian → Kalpakian* |
| Ending | truncation (ending dropped) | 2,130 | 2.8 | *Garabedian → Garabed*; *Hagopian → Agop*; *Sarkisian → Sarkis* |
| Prefix | Ter/Der/Hadji prefix added or dropped | 2,056 | 2.6 | *Garabedian → Der Garabedian*; *Bedrosian → Der Bedrossian*; *Ohannesian → Der Ohanessian* |
| Stem | h dropped or added | 2,025 | 2.6 | *Hagopian → Agopian*; *Ohannesian → Hovanessian*; *Kahramanian → Karamanian* |
| Ending | → -ov/-off (Russified) | 616 | 0.8 | *Mirzoian → Mirsoeff*; *Kardashian → Kartaschoff*; *Ketenjian → Kotandscheff* |
| Ending | → -chian/-tchian | 573 | 0.7 | *Tashjian → Tachian*; *Kochoian → Kochian*; *Kochoian → Kotchian* |
| Ending | → -jian | 484 | 0.6 | *Terzian → Terjian*; *Papazian → Papajian*; *Keshishian → Kechejian* |
| Ending | → -iants/-yants | 473 | 0.6 | *Ghazarian → Kasariantz*; *Simonian → Simonjantz*; *Torosian → Torosianz* |
| Ending | → -jan (German/Slavic romanisation) | 404 | 0.5 | *Boyajian → Boyadjan*; *Baronian → Boranjan*; *Ekmekjian → Ekmekjan* |
| Ending | → -oglou (Turkish -oğlu) | 174 | 0.2 | *Torosian → Torossoglou*; *Meterisian → Meterisoglou*; *Basmajian → Basmadjoglou* |
| Ending | → -ean (Classical orthography) | 149 | 0.2 | *Masmadzian → Masma Jean*; *Hagopian → Hagopean*; *Ounjian → Oundjean* |
| Ending | → no Armenian ending | 107 | 0.1 | *Eliasian → Elia*; *Stamboulian → Stambulia*; *Mouradian → Mouradia* |
| Ending | ending spelling only | 74 | 0.1 | *Diranian → Deranian*; *Diradourian → Deradourian*; *Dirtadian → Dertadian* |
| Ending | → -ians (Iranian-Armenian) | 51 | 0.1 | *Chamalian → Chamalians*; *Cholakian → Tchalekians*; *Bedrosian → Petrosians* |
| Ending | → -oghlian (Turkish -oğlu + -ian) | 13 | 0.0 | *Karaoghlanian → Koroglian*; *Karaoghlanian → Keuroglian*; *Karaoghlanian → Keroglian* |
| Ending | → -ova (Russified, f.) | 4 | 0.0 | *Boghosian → Pogossova*; *Mardinian → Martinova*; *Hairabedian → Airapetova* |

Given names on the same records: 65.1% Armenian national names (*Garabed*, *Sarkis*, *Mariam*), 4.4% Western
equivalents (*John*, *Peter*, *Mary*), 2.1% local names with no Armenian counterpart.

**Reading.** At the port, the stem absorbs most of the change. These changes are spelling and transmission effects
(vowels, voicing, doubling, h), not choices by the bearer. Translation and truncation are rare at entry (5% and 3%)
and belong to later stages of settlement, which the unlinked lists show.

## Part B. Profiles in present-day and 20th-century lists

### Surname endings (share of Armenian-surnamed persons)

| Ending | Glendale 2012 | Glendale 2025 | Boston 2011 | Boston 2025 | Marseille 1970–2019 | Argentina 2021 |
|---|---|---|---|---|---|---|
| *-ian* | 47.1 | 42.7 | 77.4 | 70.6 | 73.3 | 73.8 |
| *-yan* | 43.5 | 49.0 | 12.9 | 8.8 | 6.4 | 7.3 |
| *-jian* | 3.6 | 1.9 | 6.5 | 11.8 | 1.1 | 1.7 |
| *-djian* | 2.2 | 1.1 | — | 2.9 | 13.7 | 12.8 |
| *-chian / -tchian* | 2.5 | 4.2 | — | — | 5.1 | 3.6 |

Argentina: RENAPER publishes surnames only where at least 10 bearers live in a province, so rare Armenian surnames are missing and the Argentine figures describe the more frequent forms.

### Spelling features

- **Marseille:** *tch/dj* 21.1%, *ou* for *u* 13.4%, double *s* before *-ian* 11.7% (*Minassian*), Western
  consonantism 11.1%, *Ter/Der* fused 4.8% against separate 1.7%. English *oo* is practically absent.
- **Glendale:** Eastern consonantism 6.5% and initial *H* dropped through Russian transmission (*Oganesyan*,
  *Akopyan*, *Arutyunyan*) 3–4%, beside Western forms.
- **Boston:** Western consonantism 16–24%.
- **Argentina:** *-djian* 12.8% and *tch/dj* 16.2%: French-influenced Western spellings, as in Marseille.

### Given names borne with an Armenian surname

| Type | Glendale 2012 | Glendale 2025 | Boston 2025 | Marseille: born abroad | Marseille: born in France |
|---|---|---|---|---|---|
| Armenian national name | 43.8 | 35.7 | 8.8 | 46.9 | 8.9 |
| Western/Russian equivalent of an Armenian name | 8.7 | 10.5 | 20.6 | 11.6 | 35.6 |
| local name with no Armenian counterpart | 4.0 | 4.2 | 61.8 | 19.3 | 49.4 |
| Armenian name in adapted spelling (to check) | 7.2 | 8.0 | 2.9 | 6.9 | 1.5 |

(Glendale: a large residue of names are not yet classified, such as *Naira*, *Mania*, *Teni*.)

## Part C. India, 1780–1861: community register against British court (FIBIS)

Two FIBIS collections record the Calcutta Armenians through two hands:

- the **Register of births and baptisms of the Holy Nazareth Church**, 1793–1859: 1,259 entries kept by the
  community, transcribed from Armenian by R. Khachaturyan and L. Chater;
- **Armenian Names in Bengal Inventories 1780–1861**: 730 entries written by the British court, compiled by D. Atkinson,
  who marked names that may not be Armenian.

The public listings were read name by name. Each form was linked, where possible, to its Armenian base name (55 base
names with their Anglo-Indian, transliterated and European-equivalent forms), and the operation was classified.

| Indicator | British court (inventories) | Community (baptism register) |
|---|---|---|
| Surname position carries *-ean/-ian* | 0 of 730 | 121 of 1,259 |
| Given name in standard form | 5.4% | 52.5% |
| Given name replaced by a European equivalent | 8.4% | 2.1% |
| Surname position: European equivalent | 13.6% | 3.1% |
| English spelling operations per 100 given names | 31.6 | 1.9 |
| Title or rank added (Mrs, Capt, Padre, Ter, Agha) | 5.5% of given names | 2.6% of surname position (Ter, Agha) |

**Reading.** The court writes the father's or ancestor's given name as the surname, without the lineage suffix, in
English spelling:
- *ie* for *e* (Carrapiet), *oo* for *u* (Arratoon), silent *-e* (Petruse, Pogose);
- *c* for *k*, *w* for *v* (Howannes, Kawork), doubled consonants, loss of initial *h* (Arratoon < Harutyun).

It also substitutes European equivalents (Gregory, George, Peter, Lucas, Jacob) and folk-etymological ones:
Hovhannes → Owen, Melkum → Malcolm, Babajan → Babajohn. The community register keeps the Armenian forms, and about
one surname in ten keeps *-ean*.

European given names grow only slowly in the register: 3.2% before 1821, 6.5% in 1821–1840 and 8.0% in 1841–1859.
This is the same contrast between the Armenian and the English side as on the EAP1721 bilingual stones, here at the
scale of whole registers.

**Limits.**
- The "surname" field of the baptism register mostly holds the father's name, so it is a patronymic position, not a
  fixed family name.
- 10–18% of forms are not yet linked and are listed for manual review in `C_fibis_forms_linked.csv`.
- FIBIS data are cited and only aggregated; the listings themselves are not redistributed.

Files: `C_fibis_operations.csv`, `C_fibis_surname_structure.csv`, `C_fibis_given_names_by_period.csv`,
`C_fibis_forms_linked.csv` (form-level, for the authors' verification; not for publication),
`scripts/scrape_fibis.py`, `scripts/fibis_sift.py`.

## A typology of modification

1. **Transmission spellings (stem).** The same name is written through the orthography of the receiving or
   transmitting language.
   - French: *dj*, *tch*, *ch* for *sh*, *ou*, *ss* (Marseille, and AIA passengers who passed through France).
   - English: *oo*, *gh* (*Manoogian*, *Mooradian*).
   - Russian: *H* dropped or rendered *G/O* (*Oganesyan*, *Akopyan*).
   - Iranian-Armenian: *-eh* in given names (*Armineh*, *Atineh*, *Narineh*).
2. **Dialect consonantism (stem).** Western *b/g/d* against Eastern *p/k/t* (*Bedrosian/Petrosyan*,
   *Garabedian/Karapetyan*). In Glendale both series now coexist. The *-yan* forms have risen from 43.5% to 49.0%
   of the city's Armenian employees in thirteen years. This marks Eastern Armenian, post-Soviet immigration
   overtaking the older Western diaspora in the record.
3. **Ending replacement (ending).** *-ian ↔ -yan ↔ -jan ↔ -ean*; Russified *-ov/-off*; *-iants/-yants*; Turkish
   *-oğlu* (*-oglou*, *-oghlian*); Iranian-Armenian plural *-ians*.
4. **Prefix handling (prefix).** *Ter-/Der-* and *Hadji-* kept separate, fused (*Derderian*, *Deradourian*) or dropped.
5. **Truncation (ending removed).** *Garabedian → Garabed*, *Sarkisian → Sarkis*. Truncation leaves a given name as
   surname, so it often reads as foreign rather than Armenian.
6. **Translation or replacement (whole name).** *Hagopian → Jacobson*, *Jackson*; *Bedrosian → Peters*;
   *Boghosian → Paul*. These forms have no formal trace and are found only through linked records.
7. **Given-name substitution.**
   - Calque-equivalents: *Hovhannes → Jean/John/Ivan*, *Hagop → Jacques/Jack*, *Bedros → Pierre/Peter*,
     *Kevork → Georges/George*, *Krikor → Grégoire*.
   - Conventional equivalents: *Garabed → Charles*, *Yervant → Édouard/Edward*, *Harutyun → Arthur*.
   - Full replacement by a local name.
   - Folk-etymological equivalents in Calcutta: *Hovhannes → Owen*, *Melkum → Malcolm*, *Babajan → Babajohn*.
   - French feminine spellings: *-ouhie* (*Zarouhie*, *Serpouhie*, *Haigouhie*), *-ouche* (*Siranouche*).

   Marseille shows the generational step clearly. Armenian national names fall from 46.9% among the foreign-born
   to 8.9% among those born in France. Western equivalents rise from 11.6% to 35.6%, and names with no Armenian
   counterpart from 19.3% to 49.4%. Among those born in France, the surname keeps its Armenian ending while the
   given name is translated or replaced: a split adaptation.

## Methodological notes and limits

- **Evidential basis.** All counts can be recomputed with `modification_types.py` from the public sources.
  Operation classes are assigned by ordered normalisation steps, so each step is explicit and reproducible. They
  remain a first pass, to be checked against the pairs listed in Table A.
- **AIA standardisation.** The AIA "standard" form groups some distinct surnames (*Najarian/Nazarian*,
  *Arslanian/Aslanian*). Part of the "residual respelling" class is therefore regrouping, not modification.
- **Detection bias.** Unlinked lists show only names that keep a detectable Armenian feature. Translation and full
  replacement (types 6 and 7) are therefore under-counted outside the linked AIA records.
- **Boston.** The city payroll contains few Armenians (31–34 persons). Watertown, Belmont and Arlington are
  separate municipalities. The Massachusetts state payroll, or the Watertown town reports, would be the better
  New England sources.
- **Sample bias.** Payroll lists over-represent working-age, settled residents. The Marseille death register
  over-represents the generations born 1890–1950.

## Further open sources checked

- **Watertown MA:** no open name list online. Town annual reports and employee pay are available only on request.
- **Rhode Island:** state payroll portal, searchable but not bulk-downloadable, and not updated since 2025.
- **Australia:** no open bulk register of the Armenian community was found. The NSW Registry of Births, Deaths and
  Marriages has a free name-by-name index (deaths over 30 years ago, marriages over 50, births over 100), but no
  bulk export. The State Library of NSW holds oral histories of the Armenian community (2018–2019).

## Files

- `A_arslan_surname_modification_types.csv`, `A_arslan_given_name_types.csv`
- `B_detected_share_by_corpus.csv`, `B_surname_endings_by_corpus.csv`, `B_spelling_features_by_corpus.csv`,
  `B_given_name_type_by_corpus.csv`, `B_marseille_given_name_type_by_birthplace.csv`,
  `B_marseille_birth_country_of_armenian_surnamed.csv`
- `scripts/modification_types.py`, `scripts/insee_marseille.py`, `scripts/scrape_glendale_names.py`
