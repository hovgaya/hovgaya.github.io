# Ethics and data governance for the AOE name datasets (draft, 22 November 2026)

## 1. Principle: a name is an onomastic fact, not an ethnic label

AOE studies names as linguistic strings in contact. A surname with an Armenian ending is evidence about the
*history of the form*. It says nothing settled about the *identity* of its present bearer. Bearers of
*Kasparian* may not consider themselves Armenian, and bearers of *Jackson* may descend from *Hagopian*. Every output
therefore describes names and their frequencies, never persons. The detector (D7) returns the probability that a
**surname form** is of Armenian origin; it is not used to classify individuals.

## 2. Rules applied to every dataset on the site

| Rule | How it is applied |
|---|---|
| **No person-level publication** | Only aggregates are published: counts of surname forms, endings, spelling features and given-name types. Lists of employees, passengers or the deceased are never posted, even where the source is public. |
| **Minimum group size** | Example names are shown only for groups of ≥50 Armenian-surnamed persons, and only for names borne ≥3 times. The Boston groups (31 and 34 persons) are therefore published as counts only. |
| **Data minimisation** | Only the fields needed for onomastics are kept: name, sex, birth year/place where relevant. Pay data from the payroll sources and dates of death from the French register are discarded at extraction. |
| **Respect for the source's own restrictions** | The INSEE list of oppositions to republication (version of 6 May 2026) is applied before any count: 34 Marseille records are excluded. AIA material is published as aggregates until the compiler agrees otherwise. The ASL is not redistributed (§3). |
| **No linkage with sensitive attributes** | Names are never joined with health, legal-status, religious or financial information. The ASL's origin in a cancer registry is not carried into AOE in any form. |
| **Transparency of error** | Every detected surname carries its score and evidence. The site states that forms in tiers C, D and X are uncertain, and that translated names are invisible to the method. |
| **Takedown** | The site gives a contact address. Any surname form, example or record can be withdrawn on request, without justification. |
| **Purpose limitation** | The site states that the data and the detector serve onomastic and historical research. They must not be used to profile, target or screen individuals or groups. |

## 3. The Armenian Surname List (Movsisyan, Nasseri and Keegan 2023)

**Status.** The article is open access (CC BY 4.0), and a CC0 waiver applies to data *made available in the
article*. The list itself is not among those data. The supplement contains only a methods table, and the authors
state that the underlying data can be obtained from the California Department of Public Health and the California
Cancer Registry by application. The list was derived from public-use death files and the California Cancer
Registry (CCR), under approval of the State's Committee for the Protection of Human Subjects.

**Why the list cannot simply be copied in**

1. It is not published, so there is nothing openly licensed to take.
2. It was derived from health records. A rare surname that entered the list only through the cancer registry could,
   in combination with other information, point to a patient. Health data custodians therefore apply small-cell
   rules, and any release of the list is theirs and the authors' to decide.

**What the site does now (no permission needed)**

- Lists the article in the bibliography (already present) and in the Sources of the Data tab as
  *"cited, list not public."*
- Describes the method (death files + Middle Eastern Surname List, birthplace in Armenia, manual review) beside
  AOE's own detector, as a comparison of two approaches: linkage-based and form-based.

**What the site can do with the authors' agreement** (request below), in order of preference

1. **Membership only.** Use the 3,428 forms as a reference set for validating the detector; publish only the
   agreement statistics (how many ASL forms the detector places in tiers A–C), never the list.
2. **Filtered publication.** If the authors and custodians agree, publish only the forms that are also attested in
   open sources (AIA, US Census ≥100 bearers, Wikidata). No form whose only evidence is the health registry is
   published, and no counts are given.
3. **Full list.** Only if the authors confirm that the custodians permit public release, with their citation and
   terms on the site.

## 4. Draft request to the authors

> **To:** Ani S. Movsisyan (movsisyan@ucdavis.edu)
> **Subject:** Request: Armenian Surname List (BMC Med Res Methodol 2023) for an onomastic research resource
>
> Dear Dr Movsisyan,
>
> I am a linguist working on Armenian onomastics (Scientific Research Center of the Historical and Cultural
> Heritage, Yerevan; European University of Armenia). My current project documents how Armenian names change in
> contact settings, using open sources such as ship manifests, census surname tables and civil registers.
>
> Your Armenian Surname List would be a valuable independent reference for validating our surname detector, which
> scores name *forms*, not individuals. I would like to ask whether you could share the list, and on what terms.
> We would use it, in order of preference:
>
> (1) only to compute agreement statistics, without publishing the list;
> (2) or, if you and the data custodians agree, to publish only those forms that are also attested in open sources,
> without counts.
>
> Your article would be cited wherever the list is used. We would never link the list to health information or to
> individuals.
>
> With kind regards,
> Gayane R. Hovhannisyan
> ORCID 0000-0002-3480-3755 · gayane.hovhannisyan@armheritage.am

## 5. Site text for the Data tab (proposed)

```html
<h3>Use and ethics</h3>
<p>Names on this site are treated as linguistic forms. A surname of Armenian origin says nothing settled about the
identity of any person who bears it. All tables are aggregates; no list of persons is published, example names are
shown only for groups of 50 or more and names borne at least three times, and records whose publication was opposed
(INSEE register) are excluded. Data and scripts are provided for onomastic and historical research and must not be
used to profile or target individuals or groups. To request the removal of any item, write to
gayane.hovhannisyan@armheritage.am.</p>
```

Sources entry:

```html
<li>Armenian Surname List (Movsisyan, Nasseri &amp; Keegan 2023), BMC Medical Research Methodology 23: 29,
<a href="https://doi.org/10.1186/s12874-023-01848-1" target="_blank" rel="noopener">doi.org/10.1186/s12874-023-01848-1</a>:
cited; the list is not public (derived from California death files and the California Cancer Registry; access by
application to the data custodians)</li>
<li>Fichier des personnes décédées, INSEE, 1970–2019, Licence Ouverte 2.0; oppositions to republication applied
(list of 6 May 2026)</li>
<li>City of Glendale employee names via Transparent California; City of Boston Employee Earnings Report
(data.boston.gov). Names only; pay discarded; aggregates only</li>
```
