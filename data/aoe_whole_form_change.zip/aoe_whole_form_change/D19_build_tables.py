"""Rebuild A2_whole_form_change_forms.csv from a local copy of the AIA ShipManifests.csv (semicolon-delimited).
Usage: python D19_build_tables.py ShipManifests.csv outdir
Only aggregates are written. A pair is listed only if it has at least 3 distinct bearers
(estimated as distinct first names per role); rarer pairs are counted per subtype, forms withheld."""
import csv,sys,collections,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from D19_classify_whole_form_change import M,NOTES
csv.field_size_limit(10**9)
ORDER=['CONV','PARO','PATR','SEM','CONV3','CONT3','CALQ','GEN']
FN={'P':'PassengerFirstName','L':'LeavingFirstName','J':'JoiningFirstName'}
src,out=sys.argv[1],sys.argv[2]; os.makedirs(out,exist_ok=True)
agg=collections.defaultdict(lambda:{'n':0,'P':0,'L':0,'J':0,'y':[],'b':set()})
for i,x in enumerate(csv.DictReader(open(src,encoding='utf-8-sig',errors='replace'),delimiter=';')):
    y=(x['DestinationDate'] or x['OriginDate'] or '')[:4]
    for role,a,b in (('P','PassengerLastName','PassengerLastNameStd'),('L','LeavingLastName','LeavingLastNameStd'),('J','JoiningLastName','JoiningLastNameStd')):
        rec,std=(x[a] or '').strip(),(x[b] or '').strip()
        if (std,rec) not in M: continue
        g=agg[(std,rec)]; g['n']+=1; g[role]+=1
        if y.isdigit(): g['y'].append(int(y))
        fn=(x[FN[role]] or '').strip().lower() or (x['JoiningName'] or '').strip().lower() if role=='J' else (x[FN[role]] or '').strip().lower()
        g['b'].add((fn or f'?{i}',role))
with open(os.path.join(out,'A2_whole_form_change_forms.csv'),'w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['subtype_code','standard_form','recorded_form','entries','distinct_bearers_est','P','L','J','first_year','last_year','gloss_or_note'])
    for c in ORDER:
        ks=sorted([k for k in agg if M[k]==c],key=lambda k:-agg[k]['n'])
        small=[k for k in ks if len(agg[k]['b'])<3]
        for k in ks:
            g=agg[k]
            if len(g['b'])<3: continue
            w.writerow([c,k[0],k[1],g['n'],len(g['b']),g['P'],g['L'],g['J'],min(g['y'],default=''),max(g['y'],default=''),NOTES.get(k,'')])
        if small:
            w.writerow([c,'(other pairs, each <3 bearers)',f'{len(small)} pairs',sum(agg[k]['n'] for k in small),'',sum(agg[k]['P'] for k in small),sum(agg[k]['L'] for k in small),sum(agg[k]['J'] for k in small),'','','forms withheld (AOE rule: names shown only if borne by ≥3 persons)'])
