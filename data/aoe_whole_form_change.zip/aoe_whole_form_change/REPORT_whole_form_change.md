# Inside the whole-form row: who replaces an Armenian surname, and with what (D18, 25 November 2026)

## 1. Problem

The first pass over the Armenian Immigration Project (D9) put 3,951 entries (5.1%) into a single row, "whole-form change". The row mixes three different things: distinct surnames that the source groups under one standard form (*Najarian / Nazarian*), heavy clerical distortion, and real replacement. Only real replacement bears on the model. In replacement the bearer or the family abandons the Armenian string as a whole, so no segment survives in form. The question for this dataset is therefore narrower than in D9: **when a surname is replaced as a whole, what does it become, and at which point of the migration chain does that happen?**

## 2. Model

The segment model codes a name as typed segments (ECC, BASE, LIN, ORIG, PROF …) and scores each segment by the operation it undergoes. Its inventory already contains *conventional equivalence* (0.5), *lexical substitution* (0.9) and *deletion* (1.0), and its CONT set lists the contact suffixes that replace LIN while keeping its function (*-ov*, *-oğlu*, *-zade*). Whole-form replacement tests this inventory at its upper end. A replacement either keeps a relation to the source, by meaning, by convention or by sound, or it keeps none. The kind of relation decides how the replacement is coded.

## 3. Method

* **Source.** The full AIA export (ShipManifests, 78,501 entries). Each entry gives up to three surnames, each paired with a standard form: passenger (P), relative left behind (L) and relative or friend joined (J). This yields 190,992 name entries.
* **Candidates.** Pairs whose recorded form has no Armenian ending, or whose similarity to the standard form falls below 0.6 after the orthographic variables of D9 are neutralised (dj/j, ou/u, ss/s, voicing, Ter-/Der-). This gives 8,090 pairs.
* **Manual coding.** Pairs attested at least twice, and all pairs with an identifiable relation, were read one by one. A replacement is coded only where the relation between the standard and the recorded form can be stated: a gloss for translations, an equivalence for given names, phonetic resemblance for paronyms. Pairs that may be different surnames grouped by the source, and pairs that are clerical distortions, were left uncoded. The result is **151 pairs and 798 entries in eight subtypes**, about a fifth of the D9 row.
* **Role and chain.** For every coded entry the role is counted (P, L, J), and for joined contacts (J) the passenger's own surname on the same entry is checked.

**Warrant.** The coding is warranted by evidential adequacy and interpretive coherence. Each pair carries its gloss or equivalence, the source of every count is the linked record, and the classifier (D19) reproduces every table from the source file.

## 4. Results

### 4.1 Eight subtypes

| Subtype | Pairs | Entries | J share | Examples (standard → recorded, entries; only pairs borne by ≥3 persons) |
|---|---|---|---|---|
| conventional equivalent, host language | 41 | 262 | 61% | Boghosian → Paul (35); Mardirosian → Martin (23); Kaprielian → Gabriel (21) |
| paronymic substitution | 29 | 153 | 65% | Buyukian → Bacon (21); Aloian → Hallam (14); Surmanian → Sherman (9); Sandrakortzian → Sanders (7) |
| patronymic re-encoding (-son / -s) | 16 | 121 | 75% | Bedrosian → Peters (29); Ohannesian → Johnson (27); Bedrosian → Peterson (15) |
| semantic translation of a transparent base | 25 | 106 | 80% | Tashjian → Stone (23); Ouzounian → Long (7); Hatzakordzian → Baker (4); Berberian → Barber (4); Arslanian → Lion (3) |
| equivalent in a third language | 14 | 76 | 29% | Hovsepian → Youssoufian (26); Bedrosian → Petrus (5); Iskenderian → Eskandar (4); Hovsepian → Youssouf (4) |
| third-language patronymic or nisba | 13 | 46 | 22% | Kaloustian → Kaloustovitch (8); Ourfalian → Orfaly (6); Mikaelian → Michanlidou (4) |
| back-translation of a calque | 4 | 18 | 100% | Mekhitarian → Comfort (8); other pairs below the display threshold |
| generic substitution | 9 | 16 | 94% | all pairs below the display threshold |
| *baseline: all AIA name entries* | | *190,992* | *35%* | |

### 4.2 Two directions of change

The subtypes split cleanly by role. Replacements that draw on **the host language** (translation, patronymic re-encoding, paronymy, generic substitution, calque back-translation) are concentrated among **joined relatives already living in North America**, at 65–100% against a baseline of 35%. Replacements that draw on **a third language** (Arabic *Youssouf*, *Eskandar*; Latin *Petrus*; Slavic *-ović*; Greek *-idis*; Ottoman nisba *-li*) are concentrated among **passengers and the relatives they left behind**, at 71–78%. These forms are carried into North America, not made there. The record thus preserves two contact layers. One is formed before departure, in the Arabic-, Greek-, Slavic- and Turkish-speaking environments of the Ottoman and post-Ottoman world. The other is formed after settlement, in English.

### 4.3 Divergence inside the chain

Where a joined relative bears a translated surname and the passenger bears the same standard surname, the passenger usually keeps the Armenian form: semantic translation 79%, patronymic re-encoding 77%, conventional equivalence 70%. The two halves of one family are thus recorded on one line under two names. Third-language forms show the opposite pattern (0–26%): they are shared by passenger and contact.

### 4.4 Chronology

Host-language replacement rises in the 1920s. Semantic translation has 64 of its 106 entries in that decade and calque back-translation 15 of 18. This fits the hardening of American naming pressure after the First World War and the quota laws. Third-language CONT forms also peak in the 1920s (34 of 46), when the refugee routes through the Balkans, Greece and the Levant dominate the record.

## 5. Implications for the model

1. **Two operations are missing from the inventory.** *Paronymic substitution* (e.g. *Buyukian → Bacon*, *Surmanian → Sherman*) keeps neither meaning nor recoverable form, but it keeps a phonetic link that conventional equivalence and lexical substitution do not describe. *Generic substitution* keeps nothing. Both are proposed in `A2_proposed_inventory_extensions.csv`, with provisional factors (0.9 and 1.0) left for confirmation.
2. **The CONT set needs at least five further members:** *-son/-sen/-s*, *-ović*, *-idis/-idou*, *-ovna* and the nisba *-li*. Each keeps the lineage function (φ = 1), so R_func stays high while d_w is high. This is the configuration the model predicts for functional substitution.
3. **Conventional equivalence needs a target-language attribute.** *Hovsepian → Youssouf* and *Hovsepian → Joseph* are the same operation with different targets. The target language identifies the contact environment in which the operation was performed.
4. **The Christian-calque stratum can be reversed.** *Mekhitarian → Comfort* returns Մխիթար, the Armenian rendering of the Paraclete epithet, to its source meaning; rarer pairs of the same kind (for Մկրտիչ < Gk. *Baptistēs*) fall below the display threshold. The model's prediction (conversion for Christian names, translation for transparent ones) needs a third route for names that are themselves translations.
5. **Agent and direction become measurable.** The role field shows where the operation was performed (departure, port, or the settled community). It therefore separates family agency from the action of officials more directly than any single-list corpus can.

## 6. Limits

* Coverage is partial: only pairs with a statable relation were coded. Rare and opaque replacements remain in D9's residual row.
* Identifications rest on the compiler's standard forms (the bracketed links of the AIA). A translated form grouped under a different standard form is invisible here.
* Paronymic coding is interpretive. Where sound and meaning both plausibly apply the pair is coded once, by the stronger relation, and flagged in the coding sheet.

## 7. Data and ethics

All files are aggregates. No given names, ages, addresses, ship lists or images are included. Following the AOE rule, a recorded form is shown only if it is borne by at least three persons (estimated as distinct first names per role, since one joined contact can appear on several entries). Rarer pairs are counted per subtype as "other pairs, each n<3", and their forms are withheld. The source is cited, not redistributed (Armenian Immigration Project, M. B. Arslan, markarslan.org/ArmenianImmigrants). Licence: CC BY 4.0 for the tables (credit "Hovhannisyan, G. R. (2026). Armenian Onomastic Ecology (AOE)"); scripts D19 under the terms of the D-series scripts.

## Files

| File | Content |
|---|---|
| A2_whole_form_change_typology.csv | eight subtypes: definition, coding under the current model, pairs, entries, role counts, J share vs baseline |
| A2_whole_form_change_forms.csv | standard → recorded pairs borne by ≥3 persons, with role counts, first/last year, gloss; rarer pairs counted per subtype |
| A2_whole_form_change_by_decade.csv | entries by subtype and decade |
| A2_chain_divergence.csv | joined contacts with replaced surnames against the passenger's own form |
| A2_proposed_inventory_extensions.csv | proposed operations and CONT members, with examples and grounding |
| D19_classify_whole_form_change.py | the manual coding (pair → subtype, gloss) for the pairs listed in the forms table; the full coding sheet, including pairs below the display threshold, is kept by the project and available to researchers on request |
| D19_build_tables.py | rebuilds the forms table from a local copy of the source |
